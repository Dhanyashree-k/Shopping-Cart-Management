<?php
session_start();

if(isset($_POST['remove']) && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    
    // Loop through cart items and remove the item with matching product_id
    foreach($_SESSION['cart'] as $key => $item) {
        if($item['prod_id'] == $product_id) { // Changed comparison to prod_id
            unset($_SESSION['cart'][$key]);
            break; // Stop the loop once item is removed
        }
    }
    
    // Redirect back to cart.php or any other page
    header('Location: cart.php');
    exit;
}
?>
