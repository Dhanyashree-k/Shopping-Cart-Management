<?php
// Start session and check if the user is logged in
session_start();

// Destroy the session
session_destroy();

// Redirect to the register page
header('Location: register.php');
exit;
?>
