<?php
    // Start session and check if the user is logged in
    session_start();
    if(!isset($_SESSION['user_id'])) {
        // Redirect to login page if not logged in
        header('Location: login.php');
        exit;
    }

    // Include database connection
    include 'db_connection.php';

    // Retrieve user information from the database based on user_id
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM user WHERE user_id = $user_id";
    $result = mysqli_query($connection, $sql);

    if(mysqli_num_rows($result) > 0) {
        // Fetch user details
        $user_details = mysqli_fetch_assoc($result);
    } else {
        // Handle error if user not found
        echo "User not found.";
        exit;
    }

    // Process form submission for updating user details
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get updated values from the form
        $new_username = mysqli_real_escape_string($connection, $_POST['username']);
        $new_email = mysqli_real_escape_string($connection, $_POST['email']);
        $new_contact = mysqli_real_escape_string($connection, $_POST['contact']);
        $new_address = mysqli_real_escape_string($connection, $_POST['address']);

        // Update user details in the database
        $update_sql = "UPDATE user SET user_name = '$new_username', user_email = '$new_email', user_contact = '$new_contact', user_address = '$new_address' WHERE user_id = $user_id";
        if(mysqli_query($connection, $update_sql)) {
            // Update successful, redirect to account.php or display success message
            header('Location: account.php'); // Redirect to account page after update
            exit;
        } else {
            // Handle update failure
            echo "Error updating user details: " . mysqli_error($connection);
            exit;
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Profile - TechBuy</title>
    <!-- Include your CSS and other meta tags here -->
</head>
<style>
    body{
            background-image:url("pic1.gif") ;
        }
</style>
<body>
    <!-- Include your navigation bar -->
    <?php include 'navbar.php'; ?>

    <div class="container mt-5">
        <h1>Edit Profile</h1>
        <!-- Form for updating user details -->
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" id="username" name="username" value="<?= $user_details['user_name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= $user_details['user_email']; ?>" required>
            </div>
            <div class="form-group">
                <label for="contact">Contact:</label>
                <input type="text" class="form-control" id="contact" name="contact" value="<?= $user_details['user_contact']; ?>" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <textarea class="form-control" id="address" name="address" required><?= $user_details['user_address']; ?></textarea>
            </div>
            <!-- Add more fields as needed -->
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <!-- Include your JavaScript libraries and footer -->
</body>
</html>
