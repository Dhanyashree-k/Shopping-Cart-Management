<!DOCTYPE html>
<html lang="en">
<head>
    <title>TechBuy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="techbuy.jpeg" alt="TechBuy Logo">
                TechBuy.com
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Products
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="index.php?category=mobile">Mobiles</a>
                            <a class="dropdown-item" href="index.php?category=laptop">Laptops</a>
                            <a class="dropdown-item" href="index.php?category=headphone">Headphones</a>
                            <a class="dropdown-item" href="index.php?category=accessories">Accessories</a>
                            <!-- Add more category links as needed -->
                        </div>
                    </li>
                </ul>
                <!-- Cart Icon and Link -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="cart.php">
                            <i class="fas fa-shopping-cart"></i> Cart
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="account.php">Account</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin/admin_dashboard.php">Admin</a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0" method="GET" action="index.php">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search_query">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>
</body>
</html>