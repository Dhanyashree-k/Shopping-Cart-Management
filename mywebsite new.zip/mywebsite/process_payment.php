<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the payment method is selected
    if (isset($_POST['payment_method'])) {
        $payment_method = $_POST['payment_method'];

        // Handle PayPal payment method
        if ($payment_method === 'paypal') {
            // Process PayPal payment (you can implement this part)
            // For demonstration purposes, assume PayPal payment is successful
            // Redirect back to the confirmation page with success message
            header("Location: confirmation.php?success=true");
            exit;
        } elseif ($payment_method === 'credit_card') {
            // Handle Credit Card payment method
            // Process credit card payment (you can implement this part)
            // For demonstration purposes, assume credit card payment is successful
            // Redirect back to the confirmation page with success message
            header("Location: confirmation.php?success=true");
            exit;
        } else {
            // Invalid payment method selected
            echo "Invalid payment method selected.";
        }
    } else {
        // Payment method not selected
        echo "Payment method not selected.";
    }
} else {
    // Redirect the user if they try to access this page directly without submitting the form
    header("Location: purchase_confirmation.php");
    exit;
}
?>
