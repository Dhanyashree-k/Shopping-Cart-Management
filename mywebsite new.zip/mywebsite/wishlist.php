<?php
session_start();
include('db_connection.php');

if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: login.php");
    exit;
}

// Fetch wishlist items for the current user from the database
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM wishlist WHERE user_id = $user_id";
$result = mysqli_query($connection, $sql);

if (!$result) {
    echo "Error: " . mysqli_error($connection);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Add your custom CSS styles if needed -->
</head>

<body>
    <div class="container mt-5">
        <h2>Wishlist</h2>
        <div class="row">
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="<?= $row['image']; ?>" class="card-img-top" alt="<?= $row['title']; ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= $row['title']; ?></h5>
                            <p class="card-text"><?= $row['description']; ?></p>
                            <a href="#" class="btn btn-primary">Remove from Wishlist</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>

</html>
