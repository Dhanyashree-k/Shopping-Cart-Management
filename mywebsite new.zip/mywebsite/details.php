<?php
    $con = mysqli_connect('localhost', 'root');
    mysqli_select_db($con, 'mywebsite');

    // Check if prod_id is provided in the URL
    if(isset($_GET['id'])) {
        // Sanitize input
        $product_id = mysqli_real_escape_string($con, $_GET['id']);

        // Fetch product details from the database
        $sql = "SELECT * FROM products WHERE prod_id = $product_id";
        $result = mysqli_query($con, $sql);

        // Check if product exists
        if(mysqli_num_rows($result) > 0) {
            $product = mysqli_fetch_assoc($result);
        } else {
            // Product not found, redirect or display error message
            header('Location: index.php');
            exit;
        }
    } else {
        // prod_id not provided, redirect or display error message
        header('Location: index.php');
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Product Details</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="row">
                <h2 class="text-center">Product Details</h2><br><br>

                <div class="col-md-5">
                    <h4><?= $product['title']; ?></h4>
                    <img src="<?= $product['image']; ?>" alt="<?= $product['title']; ?>"/>
                    <p class="price">Rs <?= $product['price']; ?></p>
                    <p class="desc"><?= $product['description']; ?></p>
                    <p class="bname">Brand: <?= $product['brandname']; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
