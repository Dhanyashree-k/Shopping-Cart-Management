<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Confirmation</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Purchase Confirmation</h1>
        
        <!-- Success Message -->
        <?php
        if (isset($_GET['success']) && $_GET['success'] == 'true') {
            echo '<div class="alert alert-success mt-3" role="alert">Your order has been placed successfully!</div>';
        } else {
            echo '<div class="alert alert-danger mt-3" role="alert">Error processing your order. Please try again.</div>';
        }
        ?>
        
        <a href="index.php" class="btn btn-secondary mt-3">Back to Homepage</a>
    </div>
</body>
</html>
