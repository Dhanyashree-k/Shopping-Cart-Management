<?php
// Establish database connection
$con = mysqli_connect('localhost', 'root');
mysqli_select_db($con, 'mywebsite');

// Fetch products belonging to the "Mobiles" category
$sql = "SELECT * FROM products WHERE type = 'mobile'";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Mobiles</title>
    <!-- Add your CSS and other meta tags here -->
</head>
<body>
    <h1>Mobiles</h1>
    <div class="product-list">
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <!-- Display each product here -->
            <div class="product">
                <h4><?= $row['title'];?></h4>
                <img src="<?= $row['image'];?>" alt="<?= $row['title'];?>">
                <p class="price">Rs <?= $row['price'];?></p>
                <a href="details.php?id=<?= $row['prod_id']; ?>" class="btn btn-more" data-toggle="modal" data-target="#detailsModal<?= $row['prod_id']; ?>">More</a>
                <!-- Add more details if needed -->
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
