<?php
// Start session and check if the user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit;
}

// Include database connection
include 'db_connection.php';

// Retrieve user information from the database based on user_id
$user_id = $_SESSION['user_id'];
$sql_user = "SELECT * FROM user WHERE user_id = ?";
$stmt_user = mysqli_prepare($connection, $sql_user);
mysqli_stmt_bind_param($stmt_user, "i", $user_id);
mysqli_stmt_execute($stmt_user);
$result_user = mysqli_stmt_get_result($stmt_user);

if (mysqli_num_rows($result_user) > 0) {
    // Fetch user details
    $user_details = mysqli_fetch_assoc($result_user);
} else {
    // Handle error if user not found
    echo "User not found.";
    exit;
}

// Retrieve user orders from the database
$sql_orders = "SELECT * FROM orders WHERE user_id = ?";
$stmt_orders = mysqli_prepare($connection, $sql_orders);
mysqli_stmt_bind_param($stmt_orders, "i", $user_id);
mysqli_stmt_execute($stmt_orders);
$result_my_orders = mysqli_stmt_get_result($stmt_orders);
$result_manage_orders = $result_my_orders;


// Retrieve orders for the "Manage Orders" tab
$sql_manage_orders = "SELECT * FROM orders WHERE user_id = ? AND status != 'Cancelled'";
$stmt_manage_orders = mysqli_prepare($connection, $sql_manage_orders);
mysqli_stmt_bind_param($stmt_manage_orders, "i", $user_id);
mysqli_stmt_execute($stmt_manage_orders);
$result_manage_orders = mysqli_stmt_get_result($stmt_manage_orders);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <style>body{
            background-image:url("pic1.gif") ;
        }</style>
    <title>My Account - TechBuy</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Add Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="account.css">
</head>

<body>
    <!-- Include your navigation bar -->
    <?php include 'navbar.php'; ?>

    <div class="container mt-5">
        <!-- Tab buttons -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="my-orders-tab" data-toggle="tab" href="#my-orders" role="tab" aria-controls="my-orders" aria-selected="false">My Orders</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="manage-orders-tab" data-toggle="tab" href="#manage-orders" role="tab" aria-controls="manage-orders" aria-selected="false">Manage Orders</a>
            </li>
        </ul>
        <!-- Tab content -->
        <div class="tab-content" id="myTabContent">
            <!-- Profile tab content -->
            <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <div class="card mt-3">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-user"></i> Profile Details</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><strong>Username:</strong> <?= $user_details['user_name']; ?></li>
                            <li class="list-group-item"><strong>Email:</strong> <?= $user_details['user_email']; ?></li>
                            <li class="list-group-item"><strong>Contact:</strong> <?= $user_details['user_contact']; ?></li>
                            <li class="list-group-item"><strong>Address:</strong> <?= $user_details['user_address']; ?></li>
                        </ul>
                        <!-- Link to edit profile -->
                        <a href="edit_profile.php" class="btn btn-primary mt-3"><i class="fas fa-edit"></i> Edit Profile</a>
                        <!-- Logout button -->
                        <a href="logout.php" class="btn btn-danger mt-3"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>

            <!-- My Orders tab content -->
            <div class="tab-pane fade" id="my-orders" role="tabpanel" aria-labelledby="my-orders-tab">
                <div class="mt-3">
                    <h2>My Orders</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Product Name</th>
                                <th>Order Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (mysqli_num_rows($result_my_orders) > 0) {
                                while ($order_row = mysqli_fetch_assoc($result_my_orders)) {
                                    echo "<tr>";
                                    echo "<td>" . $order_row['order_id'] . "</td>";
                                    echo "<td>" . $order_row['product_name'] . "</td>";
                                    echo "<td>" . $order_row['order_date'] . "</td>";
                                    echo "<td>" . $order_row['status'] . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4'>No orders found.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Manage Orders tab content -->
            <div class="tab-pane fade" id="manage-orders" role="tabpanel" aria-labelledby="manage-orders-tab">
                <div class="mt-3">
                    <h2>Manage Orders</h2>
                    <?php
                    if (mysqli_num_rows($result_manage_orders) > 0) {
                        while ($order_row = mysqli_fetch_assoc($result_manage_orders)) {
                            ?>
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Order ID: <?= $order_row['order_id']; ?></h5>
                                    <p class="card-text">Product Name: <?= $order_row['product_name']; ?></p>
                                    <p class="card-text">Order Date: <?= $order_row['order_date']; ?></p>
                                    <p class="card-text">Status: <?= $order_row['status']; ?></p>
                                    <?php
                                    // Display cancel button only if status is pending
                                    if ($order_row['status'] == 'Pending') {
                                        ?>
                                        <!-- Cancel button -->
                                        <form method="POST" action="cancel_order.php">
                                            <input type="hidden" name="order_id" value="<?= $order_row['order_id']; ?>">
                                            <button type="submit" class="btn btn-danger" name="cancel_order">Cancel Order</button>
                                        </form>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo "<p>No orders found.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
