<?php
include_once "db_connection.php";

$username = $password = $email= $contact= $address= $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
$email_err = $contact_err = $address_err = ""; // Add these lines

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (empty(trim($_POST["user_name"]))) {
        $username_err = "Please enter a username.";
    } else {
        $sql = "SELECT user_id FROM user WHERE user_name = ?";
        if ($stmt = mysqli_prepare($connection, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = trim($_POST["user_name"]);
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $username_err = "This username is already taken.";
                } else {
                    $username = trim($_POST["user_name"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }

    // Validate password
    if (empty(trim($_POST["user_password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["user_password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["user_password"]);
    }

    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }
 // Validate email
 if (empty(trim($_POST["user_email"]))) {
    $email_err = "Please enter an email address.";
} else {
    $email = trim($_POST["user_email"]);
}

// Validate contact
if (empty(trim($_POST["user_contact"]))) {
    $contact_err = "Please enter a contact number.";
} else {
    $contact = trim($_POST["user_contact"]);
}

// Validate address
if (empty(trim($_POST["user_address"]))) {
    $address_err = "Please enter an address.";
} else {
    $address = trim($_POST["user_address"]);
}

// Check input errors before inserting into database
if (empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($email_err) && empty($contact_err) && empty($address_err)) {
    $sql = "INSERT INTO user (user_name, user_password, user_email, user_contact, user_address) VALUES (?, ?, ?, ?, ?)";
    if ($stmt = mysqli_prepare($connection, $sql)) {
        mysqli_stmt_bind_param($stmt, "sssss", $param_username, $param_password, $param_email, $param_contact, $param_address);
        $param_username = $username;
        $param_password = password_hash($password, PASSWORD_DEFAULT);
        $param_email = $email;
        $param_contact = $contact;
        $param_address = $address;
        if (mysqli_stmt_execute($stmt)) {
            header("location: index.php");
        } else {
            echo "Oops! Something went wrong. Please try again later.";
        }
        mysqli_stmt_close($stmt);
    }
}
mysqli_close($connection);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Add any necessary CSS stylesheets or external libraries here -->
</head>
<body>
    <h2>Register</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="username">Username:</label>
        <input type="text" id="username" name="user_name" value="<?php echo $username; ?>" required>
        <span><?php echo $username_err; ?></span><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="user_password" value="<?php echo $password; ?>" required>
        <span><?php echo $password_err; ?></span><br><br>
        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" value="<?php echo $confirm_password; ?>" required>
        <span><?php echo $confirm_password_err; ?></span><br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="user_email" value="<?php echo $email; ?>" required>
        <span><?php echo $email_err; ?></span><br><br>
        <label for="contact">Contact:</label>
        <input type="text" id="contact" name="user_contact" value="<?php echo $contact; ?>" required>
        <span><?php echo $contact_err; ?></span><br><br>
        <label for="address">Address:</label>
        <textarea id="address" name="user_address" required><?php echo $address; ?></textarea>
        <span><?php echo $address_err; ?></span><br><br>
        <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="login.php">Login here</a>.</p>
</body>
</html>