<?php
// Start session and check if the user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit;
}

// Include database connection
include 'db_connection.php';

// Retrieve user information from the database based on user_id
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM user WHERE user_id = $user_id";
$result = mysqli_query($connection, $sql);

if (mysqli_num_rows($result) > 0) {
    // Fetch user details
    $user_details = mysqli_fetch_assoc($result);
} else {
    // Handle error if user not found
    echo "User not found.";
    exit;
}

// Retrieve user orders from the database
$order_sql = "SELECT * FROM orders WHERE user_id = $user_id";
$order_result = mysqli_query($connection, $order_sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Manage Orders - TechBuy</title>
    <!-- Include your CSS and other meta tags here -->
    <link rel="stylesheet" href="manage_orders.css">
</head>

<body>
    <!-- Include your navigation bar -->
    <?php include 'navbar.php'; ?>

    <div class="container mt-5">
        <h1>Manage Orders</h1>
        <!-- Display user information -->
        <p>Welcome, <?= $user_details['user_name']; ?>!</p>
        <!-- Display user orders -->
        <h2>My Orders</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Product Name</th>
                    <th>Order Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($order_result) > 0) {
                    while ($order_row = mysqli_fetch_assoc($order_result)) {
                        echo "<tr>";
                        echo "<td>" . $order_row['order_id'] . "</td>";
                        echo "<td>" . $order_row['product_name'] . "</td>";
                        echo "<td>" . $order_row['order_date'] . "</td>";
                        echo "<td>" . $order_row['status'] . "</td>";
                        // Add cancel order button with AJAX functionality
                        if ($order_row['status'] == 'Pending') {
                            echo "<td><button class='btn btn-danger cancel-btn' data-order-id='" . $order_row['order_id'] . "'>Cancel</button></td>";
                        } else {
                            echo "<td>---</td>"; // Placeholder for non-cancelable orders
                        }
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No orders found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Include your JavaScript libraries and footer -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        // JavaScript function to handle cancellation of orders
        $(document).ready(function() {
            $('.cancel-btn').click(function() {
                // Get the order ID
                var orderId = $(this).data('order-id');
                // Send AJAX request to cancel_order.php
                $.ajax({
                    type: 'POST',
                    url: 'cancel_order.php',
                    data: {
                        order_id: orderId
                    },
                    success: function(response) {
                        // Parse the response JSON
                        var responseData = JSON.parse(response);
                        // Check if the status is "Cancelled"
                        if (responseData.status === 'Cancelled') {
                            // Update the status displayed on the page
                            $('.cancel-btn[data-order-id="' + orderId + '"]').closest('tr').find('td:eq(3)').text('Cancelled');
                            // Disable the cancel button
                            $('.cancel-btn[data-order-id="' + orderId + '"]').prop('disabled', true).text('Cancelled');
                        } else {
                            // Display an error message if the cancellation was unsuccessful
                            alert('Error: Unable to cancel order.');
                        }
                    },
                    error: function() {
                        // Display an error message if the AJAX request fails
                        alert('Error: Unable to cancel order. Please try again later.');
                    }
                });
            });
        });
    </script>
</body>

</html>
