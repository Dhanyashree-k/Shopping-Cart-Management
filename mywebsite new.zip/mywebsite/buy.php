<?php
session_start();

// Check if the action is 'add' and if product_id is provided
if(isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['product_id'])) {
    // Connect to database
    $con = mysqli_connect('localhost', 'root', '', 'mywebsite'); // Update database name here
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    // Check if the user is logged in
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $product_id = mysqli_real_escape_string($con, $_GET['product_id']);

        // Insert the product into the cart table
        $sql = "INSERT INTO cart (user_id, prod_id) VALUES ('$user_id', '$product_id')";
        if (mysqli_query($con, $sql)) {
            // Product added to cart successfully, redirect back to the previous page
            header('Location: ' . $_SERVER['HTTP_REFERER']);
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($con);
        }
    } else {
        // User is not logged in, handle accordingly
        echo "User is not logged in.";
    }
    
    mysqli_close($con); // Close the database connection
} else {
    // Invalid request, redirect or show error message
    echo "Invalid request.";
}
?>
