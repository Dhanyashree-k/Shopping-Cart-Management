<?php
include_once "db_connection.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $prod_id = $_POST["prod_id"];
    $type = $_POST["type"];
    $title = $_POST["title"];
    $price = $_POST["price"];
    $brandname = $_POST["brandname"];
    $description = $_POST["description"];
    $featured = isset($_POST["featured"]) ? 1 : 0;

    // Update the existing product in the database
    $query = "UPDATE products SET type = '$type', title = '$title', price = $price, brandname = '$brandname', description = '$description', featured = $featured WHERE prod_id = $prod_id";

    // Execute the query
    $result = mysqli_query($connection, $query);

    if ($result) {
        // Product updated successfully
        header("Location: manage_products.php");
        exit();
    } else {
        // Error updating product
        echo "Error: " . mysqli_error($connection);
    }
}
?>
