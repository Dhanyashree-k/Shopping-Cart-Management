<?php
// Include database connection code
include_once "db_connection.php";

// Check if product ID is provided in the URL
if (isset($_GET['id'])) {
    $prod_id = $_GET['id'];
    
    // Delete product from the database
    $query = "DELETE FROM products WHERE prod_id = $prod_id";
    $result = mysqli_query($connection, $query);

    if ($result) {
        // Product deleted successfully
        echo "<script>alert('Product deleted successfully.');</script>";
    } else {
        // Error deleting product
        echo "<script>alert('Error deleting product.');</script>";
    }
} else {
    // Product ID not provided
    echo "<script>alert('Product ID not provided.');</script>";
}

// Redirect back to the manage products page
header("Location: manage_products.php");
exit();
?>
