<?php
include_once "db_connection.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $type = $_POST["type"];
    $title = $_POST["title"];
    $price = $_POST["price"];
    $brandname = $_POST["brandname"];
    $description = $_POST["description"];
    $featured = isset($_POST["featured"]) ? 1 : 0;

    // Insert a new product into the database
    $query = "INSERT INTO products (type, title, price, brandname, description, featured) VALUES ('$type', '$title', $price, '$brandname', '$description', $featured)";

    // Execute the query
    $result = mysqli_query($connection, $query);

    if ($result) {
        // Product saved successfully
        header("Location: manage_products.php");
        exit();
    } else {
        // Error saving product
        echo "Error: " . mysqli_error($connection);
    }
}
?>
