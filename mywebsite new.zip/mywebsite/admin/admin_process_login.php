<?php
// Start session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection code or functions
    include_once "db_connection.php";

    // Get username and password from the form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Validate username and password
    // This is a basic example, you should use secure password hashing and validation methods
    if ($username && $password) {
        // Query the database to check if the admin exists
        $query = "SELECT * FROM admin WHERE admin_name = ? AND admin_password = ?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, "ss", $username, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        // Check if the query returned any rows
        if ($result && mysqli_num_rows($result) == 1) {
            // Admin exists, set session variables and redirect to admin dashboard
            $admin_data = mysqli_fetch_assoc($result);
            $_SESSION["admin_id"] = $admin_data["admin_id"];
            $_SESSION["admin_name"] = $admin_data["admin_name"];
            header("Location: admin_dashboard.php");
            exit();
        } else {
            // Admin does not exist or incorrect credentials, show error message
            echo "Invalid username or password. Please try again.";
        }
    } else {
        // Username or password not provided, show error message
        echo "Please enter both username and password.";
    }
} else {
    // If the form is not submitted, redirect to admin login page
    header("Location: admin_login.php");
    exit();
}
?>
