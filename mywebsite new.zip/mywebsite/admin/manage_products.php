<?php
// Include database connection code
include_once "db_connection.php";

// Fetch products from the database
$query = "SELECT * FROM products";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color:beige;
        }

        h2 {
            text-align: center;
            margin-top: 20px;
        }

        a {
            display: block;
            width: 100px;
            text-align: center;
            margin: 20px auto;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color:mediumpurple;
            color: #fff;
        }

        img {
            max-width: 100px;
            height: auto;
        }

        td a {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <h2>Manage Products</h2>
    <a href="add_product.php">Add New Product</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Title</th>
                <th>Price</th>
                <th>Brand</th>
                <th>Description</th>
                <th>Featured</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['prod_id']; ?></td>
                    <td><?php echo $row['type']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                    <td><?php echo $row['brandname']; ?></td>
                    <td><?php echo $row['description']; ?></td>
                    <td><?php echo ($row['featured'] == 1) ? 'Yes' : 'No'; ?></td>
                    <td><img src="<?php echo $row['image']; ?>" alt="Product Image"></td>
                    <td>
                        <a href="edit_product.php?id=<?php echo $row['prod_id']; ?>">Edit</a>
                        <a href="delete_product.php?id=<?php echo $row['prod_id']; ?>" onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
