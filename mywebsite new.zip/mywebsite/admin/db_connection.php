<?php
// Database configuration
$host = "localhost"; // Your database host (typically localhost)
$username = "root"; // Your MySQL username (usually root by default)
$password = ""; // Your MySQL password (leave empty if none)
$database = "mywebsite"; // Your database name

// Create connection
$connection = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
