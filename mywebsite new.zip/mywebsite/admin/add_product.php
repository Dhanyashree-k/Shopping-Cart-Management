<?php
include_once "db_connection.php";

// Initialize variables for form fields
$type = '';
$title = '';
$price = '';
$brandname = '';
$description = '';
$featured = '';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $type = $_POST["type"];
    $title = $_POST["title"];
    $price = $_POST["price"];
    $brandname = $_POST["brandname"];
    $description = $_POST["description"];
    $featured = isset($_POST["featured"]) ? 1 : 0;

    // Check if an image file is uploaded
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
        $target_dir = "mywebsite/images/"; // Adjusted target directory path
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if the file is an actual image
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check !== false) {
            // Create target directory if it doesn't exist
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true); // Recursive directory creation
            }

            // Move uploaded file to the target directory
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $image = $target_file;
            } else {
                // Failed to move uploaded file
                echo "Error uploading image.";
                exit();
            }
        } else {
            // File is not an image
            echo "File is not an image.";
            exit();
        }
    }

    // Add new product to the database
    $query = "INSERT INTO products (type, title, price, brandname, description, featured, image) VALUES ('$type', '$title', $price, '$brandname', '$description', $featured, '$image')";

    // Execute the query
    $result = mysqli_query($connection, $query);

    if ($result) {
        // Product saved successfully
        header("Location: manage_products.php");
        exit();
    } else {
        // Error saving product
        echo "Error: " . mysqli_error($connection);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
            resize: vertical;
        }

        input[type="checkbox"] {
            margin-right: 5px;
            vertical-align: middle;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h2>Add New Product</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
        <label for="type">Type:</label>
        <input type="text" id="type" name="type" value="<?php echo $type; ?>" required>
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" value="<?php echo $title; ?>" required>
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" value="<?php echo $price; ?>" required>
        <label for="brandname">Brand:</label>
        <input type="text" id="brandname" name="brandname" value="<?php echo $brandname; ?>" required>
        <label for="description">Description:</label>
        <textarea id="description" name="description" required><?php echo $description; ?></textarea>
        <label for="featured">Featured:</label>
        <input type="checkbox" id="featured" name="featured" <?php echo ($featured == 1) ? 'checked' : ''; ?>>
        <!-- Add file input for image -->
        <label for="image">Image:</label><br>
        <input type="file" id="image" name="image"><br><br><br>
        <button type="submit">Save</button>
    </form>
</body>
</html>
