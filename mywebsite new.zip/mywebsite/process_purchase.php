<?php
session_start();

// Include database connection code
include_once "db_connection.php";

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Retrieve cart items from the database for the current user
    $cart_sql = "SELECT products.*, cart.cart_id, cart.quantity, cart.prod_id FROM products INNER JOIN cart ON products.prod_id = cart.prod_id WHERE cart.user_id = ?";
    $stmt_cart = $connection->prepare($cart_sql);
    $stmt_cart->bind_param("i", $user_id);
    $stmt_cart->execute();
    $cart_result = $stmt_cart->get_result();

    if (!$cart_result) {
        die("Error fetching cart items: " . $connection->error);
    }

    // Check if cart has items
    if ($cart_result->num_rows > 0) {
        $cart_items = $cart_result->fetch_all(MYSQLI_ASSOC);
        
        // Calculate total price
        $total_price = 0;
        foreach ($cart_items as $item) {
            $total_price += $item['price'] * $item['quantity'];
        }
        
        // Insert cart items into the orders table
        $insert_order_sql = "INSERT INTO orders (user_id, prod_id, product_name, quantity, total_price, order_date, status) VALUES (?, ?, ?, ?, ?, NOW(), 'Pending')";
        $stmt_insert_order = $connection->prepare($insert_order_sql);
        foreach ($cart_items as $item) {
            $stmt_insert_order->bind_param("iiisi", $user_id, $item['prod_id'], $item['title'], $item['quantity'], $total_price);
            $stmt_insert_order->execute();
        }

        // Clear the cart after successful purchase
        $clear_cart_sql = "DELETE FROM cart WHERE user_id = ?";
        $stmt_clear_cart = $connection->prepare($clear_cart_sql);
        $stmt_clear_cart->bind_param("i", $user_id);
        $stmt_clear_cart->execute();

        // Redirect to the purchase confirmation page
        header("Location: purchase_confirmation.php?success=true");
        exit();
    } else {
        // Handle case where cart is empty
        echo "Your cart is empty. Please add items to your cart before proceeding.";
    }
} else {
    // Handle case where user is not logged in
    echo "User is not logged in.";
}
?>
