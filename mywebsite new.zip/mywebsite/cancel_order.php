<?php
// Include database connection
include 'db_connection.php';

// Check if order_id is set and not empty
if(isset($_POST['order_id']) && !empty($_POST['order_id'])) {
    // Sanitize the order_id
    $order_id = mysqli_real_escape_string($connection, $_POST['order_id']);

    // Prepare the SQL statement
    $update_sql = "UPDATE orders SET status = 'Cancelled' WHERE order_id = ?";
    $stmt = mysqli_prepare($connection, $update_sql);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "i", $order_id);

    // Execute the statement
    $update_result = mysqli_stmt_execute($stmt);

    if($update_result) {
        // Return success message
        echo "Order successfully cancelled.";
    } else {
        // Return error message
        echo "Error updating order status.";
    }
} else {
    // Return error message if order_id is not set or empty
    echo "Invalid order ID.";
}
?>
